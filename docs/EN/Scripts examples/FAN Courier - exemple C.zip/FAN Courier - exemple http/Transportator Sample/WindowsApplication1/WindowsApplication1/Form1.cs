using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using lib_http;
using System.Net;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HTTP wr = new HTTP(false); 
            String mresp;
            String comanda;

            comanda = "--AaB03x\r\n";
            comanda = comanda + "Content-Disposition: form-data; name=\"username\"\r\n\r\n";
            comanda = comanda + "danac\r\n";
            comanda = comanda + "--AaB03x\r\n";
            comanda = comanda + "Content-Disposition: form-data; name=\"user_pass\"\r\n\r\n";
            comanda = comanda + "fan\r\n";
            comanda = comanda + "--AaB03x\r\n";
            comanda = comanda + "Content-Disposition: form-data; name=\"client_id\"\r\n\r\n";
            comanda = comanda + "4747170\r\n";
            comanda = comanda + "--AaB03x\r\n";
            comanda = comanda + "Content-Disposition: form-data; name=\"fisier\"; filename=\"fancurier-export-awb-05.05.2009-OK.csv\"\r\n";
            comanda = comanda + "Content-Type: text/xml\r\n\r\n";
            comanda = comanda + "Tip serviciu,Banca,IBAN,Nr. Plicuri,Nr. Colete,Greutate,Plata expeditie,Ramburs,Plata ramburs la,Valoare declarata,Pers cont exp,Observatii,Continut,Nume destinatar,Persoana contact,Telefon,Fax,Email,Judet,Localitatea,Strada,Nr,Cod postal,Bloc,Scara,Etaj,Apartament\r\n";
            comanda = comanda + "Standard,,,1,1,1,expeditor,12.1,destinatar,0,persoana contact,,[continut], Cursaru Floarea, Cursaru Floarea,9336,,email@server.com,Bucuresti,Bucuresti,Str.Ograda. nr.764 ,,12345,,,,\r\n";
            comanda = comanda + "Standard,,,1,1,1,expeditor,1,destinatar,0,persoana contact,,[continut], Iosub Raluca, Iosub Raluca,9336,,email@server.com,Bucuresti,Bucuresti,Strada Vasile Lupu 89  Bl V2 Sc A  Et 4  Ap1,,12345,,,,\r\n";
            comanda = comanda + "Standard,,,1,1,1,expeditor,0,destinatar,0,persoana contact,,[continut], tiron tatieana, tiron tatieana,9336,,email@server.com,Bucuresti,Bucuresti,iasi str. mircea cel batrin nr 7 blO1 scB et III ap2 ,,12345,,,,\r\n";
            comanda = comanda + "Standard,,,1,1,1,expeditor,12,destinatar,0,persoana contact,,[continut], Szoke Adina, Szoke Adina,9336,,email@server.com,Bucuresti,Bucuresti,str Biharia nr 26 sect 1 Bucuresti ,,12345,,,,\r\n";
            comanda = comanda + "Standard,,,1,1,1,expeditor,0,destinatar,0,persoana contact,,[continut], Marian Bogdan Zeic, Marian Bogdan Zeic,9336,,email@server.com,Bucuresti,Bucuresti,Maestro Business Center B-dul 21 Decembrie 1989  Nr. 104  et.3,,12345,,,,\r\n";
            comanda = comanda + "Standard,,,1,1,1,expeditor,12,destinatar,0,persoana contact,,[continut], Edroi Valentina, Edroi Valentina,9336,,email@server.com,Bucuresti,Bucuresti,Str. Transilvaniei  Nr. 28,,12345,,,,\r\n";
            comanda = comanda + "Standard,,,1,1,1,expeditor,12,destinatar,12.3,persoana contact,,[continut], Circea Bianca, Circea Bianca,9336,,email@server.com,Bucuresti,Bucuresti,Str. Ciresului nr. 6  sector 3 trezoreria sectorului 3 etaj 1,,12345,,,,\r\n";
            comanda = comanda + "--AaB03x--/r/n";

            mresp = wr.Post("www.selfawb.ro", "http://www.selfawb.ro/import_awb_integrat.php",comanda, "");
            MessageBox.Show(mresp);
        }

    }
}