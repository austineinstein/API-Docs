﻿Imports System.Net
Imports System.IO
Imports System.Collections.Specialized

Partial Class Beta_AwS

    Private Shared Function InlineAssignHelper(Of T)(ByRef target As T, ByVal value As T) As T
        target = value
        Return value
    End Function

    Public Shared Function HttpUploadFile(ByVal url As String, ByVal file As String, ByVal paramName As String, ByVal contentType As String, ByVal nvc As NameValueCollection) As String
        Dim result As String = ""

        Dim boundary As String = "---------------------------" & DateTime.Now.Ticks.ToString("x")
        Dim boundarybytes As Byte() = System.Text.Encoding.ASCII.GetBytes(vbCr & vbLf & "--" & boundary & vbCr & vbLf)

        Dim wr As HttpWebRequest = DirectCast(WebRequest.Create(url), HttpWebRequest)
        wr.ContentType = "multipart/form-data; boundary=" & boundary
        wr.Method = "POST"
        wr.KeepAlive = True
        wr.Credentials = System.Net.CredentialCache.DefaultCredentials

        Dim rs As Stream = wr.GetRequestStream()

        Dim formdataTemplate As String = "Content-Disposition: form-data; name=""{0}""" & vbCr & vbLf & vbCr & vbLf & "{1}"
        For Each key As String In nvc.Keys
            rs.Write(boundarybytes, 0, boundarybytes.Length)
            Dim formitem As String = String.Format(formdataTemplate, key, nvc(key))
            Dim formitembytes As Byte() = System.Text.Encoding.UTF8.GetBytes(formitem)
            rs.Write(formitembytes, 0, formitembytes.Length)
        Next
        rs.Write(boundarybytes, 0, boundarybytes.Length)

        Dim headerTemplate As String = "Content-Disposition: multipart/form-data; charset=UTF-8; name=""{0}""; filename=""{1}""" & vbCr & vbLf & "Content-Type: {2}" & vbCr & vbLf & vbCr & vbLf
        Dim header As String = String.Format(headerTemplate, paramName, file, contentType)
        Dim headerbytes As Byte() = System.Text.Encoding.UTF8.GetBytes(header)
        rs.Write(headerbytes, 0, headerbytes.Length)

        Dim fileStream As New FileStream(file, FileMode.Open, FileAccess.Read)
        Dim buffer As Byte() = New Byte(4095) {}
        Dim bytesRead As Integer = 0
        While (InlineAssignHelper(bytesRead, fileStream.Read(buffer, 0, buffer.Length))) <> 0
            rs.Write(buffer, 0, bytesRead)
        End While

        fileStream.Close()

        Dim trailer As Byte() = System.Text.Encoding.ASCII.GetBytes(vbCr & vbLf & "--" & boundary & "--" & vbCr & vbLf)
        rs.Write(trailer, 0, trailer.Length)
        rs.Close()

        Dim wresp As WebResponse = Nothing
        Try

            'Get response
            Dim _response As WebResponse = wr.GetResponse()
            Dim stream2 As Stream = _response.GetResponseStream()
            Dim reader2 As StreamReader = New StreamReader(stream2)
            result = reader2.ReadToEnd()
            _response.Close()
            wr = Nothing
            wr = Nothing

        Catch ex As Exception

            If wresp IsNot Nothing Then
                wresp.Close()
                wresp = Nothing
            End If
        Finally
            wr = Nothing
        End Try

        Return result
    End Function
End Class

'comanda = "--AaB03x" & vbcrlf 
'comanda = comanda & "Content-Disposition: form-data; name=\""username\""" & vbcrlf  & vbcrlf 
'comanda = comanda & "danac" & vbcrlf 
'comanda = comanda & "--AaB03x" & vbcrlf 
'comanda = comanda & "Content-Disposition: form-data; name=\""user_pass\""" & vbcrlf  & vbcrlf 
'comanda = comanda & "fan" & vbcrlf 
'comanda = comanda & "--AaB03x" & vbcrlf 
'comanda = comanda & "Content-Disposition: form-data; name=\""client_id\""" & vbcrlf  & vbcrlf 
'comanda = comanda & "4747170" & vbcrlf 
'comanda = comanda & "--AaB03x" & vbcrlf 
'comanda = comanda & "Content-Disposition: form-data; name=\""fisier\""; filename=\""fancurier-export-awb-05.05.2009-OK.csv\""" & vbcrlf 
'comanda = comanda & "Content-Type: text/xml" & vbcrlf  & vbcrlf 
'comanda = comanda & "Tip serviciu,Banca,IBAN,Nr. Plicuri,Nr. Colete,Greutate,Plata expeditie,Ramburs,Plata ramburs la,Valoare declarata,Pers cont exp,Observatii,Continut,Nume destinatar,Persoana contact,Telefon,Fax,Email,Judet,Localitatea,Strada,Nr,Cod postal,Bloc,Scara,Etaj,Apartament" & vbcrlf 
'comanda = comanda & "Standard,,,1,1,1,expeditor,12.1,destinatar,0,persoana contact,,[continut], Cursaru Floarea, Cursaru Floarea,9336,,email@server.com,Bucuresti,Bucuresti,Str.Ograda. nr.764 ,,12345,,,," & vbcrlf 
'comanda = comanda & "Standard,,,1,1,1,expeditor,1,destinatar,0,persoana contact,,[continut], Iosub Raluca, Iosub Raluca,9336,,email@server.com,Bucuresti,Bucuresti,Strada Vasile Lupu 89  Bl V2 Sc A  Et 4  Ap1,,12345,,,," & vbcrlf 
'comanda = comanda & "Standard,,,1,1,1,expeditor,0,destinatar,0,persoana contact,,[continut], tiron tatieana, tiron tatieana,9336,,email@server.com,Bucuresti,Bucuresti,iasi str. mircea cel batrin nr 7 blO1 scB et III ap2 ,,12345,,,," & vbcrlf 
'comanda = comanda & "Standard,,,1,1,1,expeditor,12,destinatar,0,persoana contact,,[continut], Szoke Adina, Szoke Adina,9336,,email@server.com,Bucuresti,Bucuresti,str Biharia nr 26 sect 1 Bucuresti ,,12345,,,," & vbcrlf 
'comanda = comanda & "Standard,,,1,1,1,expeditor,0,destinatar,0,persoana contact,,[continut], Marian Bogdan Zeic, Marian Bogdan Zeic,9336,,email@server.com,Bucuresti,Bucuresti,Maestro Business Center B-dul 21 Decembrie 1989  Nr. 104  et.3,,12345,,,," & vbcrlf 
'comanda = comanda & "Standard,,,1,1,1,expeditor,12,destinatar,0,persoana contact,,[continut], Edroi Valentina, Edroi Valentina,9336,,email@server.com,Bucuresti,Bucuresti,Str. Transilvaniei  Nr. 28,,12345,,,," & vbcrlf 
'comanda = comanda & "Standard,,,1,1,1,expeditor,12,destinatar,12.3,persoana contact,,[continut], Circea Bianca, Circea Bianca,9336,,email@server.com,Bucuresti,Bucuresti,Str. Ciresului nr. 6  sector 3 trezoreria sectorului 3 etaj 1,,12345,,,," & vbcrlf 
'comanda = comanda & "--AaB03x--/r/n"

'strRequest = "POST " & "https://www.selfawb.ro/import_awb_integrat.php &" & " HTTP/1.1" & vbcrlf 
'strRequest = strRequest & "Host: " & "www.selfawb.ro"  & vbcrlf 
'strRequest = strRequest & "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.7) Gecko/20050414 Firefox/1.0.3" & vbcrlf 
'strRequest = strRequest & "Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/ *;q=0.5" & vbcrlf 
'strRequest = strRequest & "Accept-Language: en-us,en;q=0.5" & vbcrlf 
'strRequest = strRequest & "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7" & vbcrlf 
'strRequest = strRequest & "Accept-Encoding: gzip, deflate" & vbcrlf 
'strRequest = strRequest & "Referer: "   & vbcrlf 
'strRequest = strRequest & "Cookie: "   & vbcrlf 
'strRequest = strRequest & "Content-Type: multipart/form-data; boundary=AaB03x" & vbcrlf 
'strRequest = strRequest & "Content-Length: " & comanda.Length.ToString()  & vbcrlf 
'strRequest = strRequest & "Connection: close" & vbcrlf  & vbcrlf 
'strRequest = strRequest & comanda  & vbcrlf 
