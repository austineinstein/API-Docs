﻿Imports System.Collections.Specialized
Imports System.IO

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim nvc As New NameValueCollection()
        nvc.Add("username", "danac")
        nvc.Add("client_id", "4747170")
        nvc.Add("user_pass", "fan")
        Beta_AwS.HttpUploadFile("https://www.selfawb.ro/import_awb_integrat.php", "C:\Documents and Settings\bogdans\Desktop\x\test.csv", "fisier", "text/xml\r\n\r\n", nvc)
    End Sub
End Class

