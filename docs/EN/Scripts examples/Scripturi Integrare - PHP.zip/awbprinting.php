<?php




   $ch = curl_init('http://www.selfawb.ro/view_awb_integrat.php'); 


   curl_setopt($ch, CURLOPT_POST, 1);

   curl_setopt($ch, CURLOPT_HTTPHEADERS,array('Content-Type: multipart/form-data'));

   curl_setopt($ch, CURLOPT_POSTFIELDS, array('nr'=>'2284100120001','username'=>'mariusi','client_id'=>'7024738','user_pass' => 'pwd^test$123' ));

   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

   curl_setopt($ch,CURLOPT_FAILONERROR,true);

   $postResult = curl_exec($ch);

 

   curl_close($ch);

   print "<br><br>$postResult"; 

?>
