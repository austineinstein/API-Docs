<?php

$vusername="mariusi";
$vuser_pass="pwd^test$123";
$vclient_id="7024738";
$vpers_contact="expeditor";
$vtel="standard";
$vemail="Constanta";
$vnr_colete="2";
$vnr_plicuri="0";
$vgreutate="1";
$vinaltime="20";
$vlungime="20";
$vlatime="10";
$vora_ridicare="17:00";
$vobservatii="teeest order";
$vstrada="plesesti";
$vnr="3";
$vbloc="z12";
$vscara="11";
$vetaj="";
$vap="";
$vlocalitate="Brasov";
$vjudet="Brasov";




$url = 'http://www.selfawb.ro/comanda_curier_integrat.php';
$c = curl_init ($url);
curl_setopt ($c, CURLOPT_POST, true);
curl_setopt ($c, CURLOPT_POSTFIELDS, "username=$vusername&user_pass=$vuser_pass&client_id=$vclient_id&pers_contact=$vpers_contact&tel=$vtel&email=$vemail&nr_colete=$vnr_colete&nr_plicuri=$vnr_plicuri&greutate=$vgreutate&inaltime=$vinaltime&lungime=$vlungime&latime=$vlatime&ora_ridicare=$vora_ridicare&observatii=$vobservatii&strada=$vstrada&nr=$vnr&bloc=$vbloc&scara=$vscara&etaj=$vetaj&ap=$vap&localitate=$vlocalitate&judet=$vjudet");
curl_setopt ($c, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec ($c);
curl_close ($c);
echo $page;
?>