<?php

$username="mariusi";
$parola="pwd^test$123";
$clientid="7024738";
$platala="expeditor";
$tipserviciu="standard";
$localitatedestinatar="Constanta";
$judetdestinatar="Constanta";
$plicuri="1";
$colete="0";
$greutate="1";
$lungime="0";
$latime="0";
$inaltime="0";
$valoaredeclarata="10";
$plataramburs="";


$url = 'http://www.selfawb.ro/tarif.php';
$c = curl_init ($url);
curl_setopt ($c, CURLOPT_POST, true);
curl_setopt ($c, CURLOPT_POSTFIELDS, "username=$username&user_pass=$parola&client_id=$clientid&plata_la=$platala&serviciu=$tipserviciu&localitate_dest=$localitatedestinatar&judet_dest=$judetdestinatar&plicuri=$plicuri&colete=$colete&greutate=$greutate&lungime=$lungime&latime=$latime&inaltime=$inaltime&val_decl=$valoaredeclarata&plata_ramburs=$plataramburs");
curl_setopt ($c, CURLOPT_RETURNTRANSFER, true);
$page = curl_exec ($c);
curl_close ($c);
echo $page;
?>